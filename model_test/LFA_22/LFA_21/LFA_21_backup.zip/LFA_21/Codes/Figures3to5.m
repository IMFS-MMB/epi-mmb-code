% Figures 3 to 5 in "The Limited Power of Monetary Policy in a Pandemic",
% Antoine Lepetit and Cristina Fuentes-Albero, November 2021.
% This program reads the matrices Xn_baseline, Xn, Xn_2, and Xn_3 produced
% by the program irf_mpshock.m.

clear all
clc

load Xn_baseline;
load Xn;
load Xn_2;
load Xn_3;

figure(1);
plot(100.*(Xn(13,1:120,1)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,10)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,20)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,30)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,40)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,50)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,60)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,70)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn(13,1:120,80)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
legend({'Revealed time 1','Revealed time 10','Revealed time 20','Revealed time 30','Revealed time 40','Revealed time 50','Revealed time 60','Revealed time 70','Revealed time 80'},'Location','east','Fontsize',16);
xlabel('Weeks','Fontsize',16);
ylabel('Output (% deviation)','Fontsize',16);

figure(2);
plot(100.*(Xn_2(13,1:120,1)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn_2(13,1:120,20)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'--','LineWidth',3);
hold on
plot(100.*(Xn_2(13,1:120,50)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'-.','LineWidth',3);
hold on
plot(100.*(Xn_2(13,1:120,80)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),':','LineWidth',3);
xlim([0 100])
legend({'Horizon 1','Horizon 20','Horizon 50','Horizon 80'},'Location','southeast','Fontsize',16);
xlabel('Weeks','Fontsize',16);
ylabel('Output (% deviation)','Fontsize',16);

figure(3);
plot(100.*(Xn_3(13,1:120,1)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'LineWidth',3);
hold on
plot(100.*(Xn_3(13,1:120,20)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'--','LineWidth',3);
hold on
plot(100.*(Xn_3(13,1:120,50)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),'-.','LineWidth',3);
hold on
plot(100.*(Xn_3(13,1:120,80)-Xn_baseline(13,1:120))./Xn_baseline(13,1:120),':','LineWidth',3);
xlim([0 100])
legend({'Revealed time 1','Revealed time 20','Revealed time 50','Revealed time 80'},'Location','northwest','Fontsize',16);
xlabel('Weeks','Fontsize',16);
ylabel('Output (% deviation)','Fontsize',16);