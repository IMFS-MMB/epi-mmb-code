% Figures 6 and 7 in "The Limited Power of Monetary Policy in a Pandemic",
% Antoine Lepetit and Cristina Fuentes-Albero, November 2021.

%% Preparation

clear all
clc

mp_pandemic_zlb;

global M_ options_ oo_;
Tsim = 150;
options_.periods = Tsim;
options_.simul.maxit = 200; 
options_.dynatol.f = 1e-10;
options_.dynatol.x = 1e-10;

maxlag=1;
maxlead=1;
endo_simul = repmat(oo_.endo_simul(:,1),[1,Tsim+maxlag+maxlead]);
endo_simul(:,end) = oo_.endo_simul(:,end);
oo_.endo_simul = endo_simul;

% Calibrate shocks
mu = [zeros(Tsim+1,1)];
mp_shock = [zeros(Tsim+1,1)];
pi_s1_shock = [zeros(Tsim+1,1)];
pi_s2_shock = [0;0;0;0;-0.02;-0.04;-0.06;-0.08*ones(Tsim+1-7,1)];
pi_s3_shock = [-0.19;-0.19;-0.195;-0.195;-0.2025*ones(5,1);-0.205*ones(5,1);-0.2075*ones(10,1);-0.21*ones(Tsim+1-24,1)];

shocks = [mu,mp_shock,pi_s1_shock,pi_s2_shock,pi_s3_shock];

eps_t = shocks(1:2,:);
Tshock = size(eps_t,1);
nshock = size(eps_t,2);

%% Simulate baseline

Xn_baseline = endo_simul;

for h=1:Tshock
    
    display(sprintf('Now on time %d', h));
    
    options_.periods = Tsim-h+1;
    
    oo_.exo_simul = [zeros(1,nshock);eps_t(h,:);[zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),pi_s2_shock(h+1:end),pi_s3_shock(h+1:end)]];
    perfect_foresight_solver;
    
    Xn_baseline(:,h+1:end) = real(oo_.endo_simul(:,2:end));
    oo_.endo_simul = real(oo_.endo_simul(:,2:end));
    
end

clear oo_.endo_simul oo_.exo_simul shocks eps_t Tshock nshock;


%% Pick up path for FFR and simulate sim with extended path

rff_treshold =  Xn_baseline(10,2:end)';
ffr_trigger = rff_treshold;

counter_shock = ones(Tsim+1,1);

shocks = [mu,mp_shock,pi_s1_shock,pi_s2_shock,pi_s3_shock,ffr_trigger,counter_shock];
eps_t = shocks(1:2,:);
Tshock = size(eps_t,1);
nshock = size(eps_t,2);

mp_pandemic_extended

endo_simul = repmat(oo_.endo_simul(:,1),[1,Tsim+maxlag+maxlead]);
endo_simul(:,end) = oo_.endo_simul(:,end);
oo_.endo_simul = endo_simul;

Xn_extended = endo_simul;

for h=1:Tshock
    
    display(sprintf('Now on time %d', h));
    
    options_.periods = Tsim-h+1;
    
    oo_.exo_simul = [zeros(1,nshock);eps_t(h,:);[zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),pi_s2_shock(h+1:end),pi_s3_shock(h+1:end),ffr_trigger(h+1:end),counter_shock(h+1:end)]];
    perfect_foresight_solver;
    
    Xn_extended(:,h+1:end) = real(oo_.endo_simul(:,2:end));
    oo_.endo_simul = real(oo_.endo_simul(:,2:end));
    
end

clear oo_.endo_simul oo_.exo_simul mp_shock shocks eps_t Tshock nshock;

%% Figures

figure(1);
plot(Xn_baseline(3,2:100),'b','LineWidth',3);
hold on
plot(Xn_extended(3,2:100),'--r','LineWidth',3);
title('Infected','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Fraction of the population','Fontsize',18)

figure(2);
plot(Xn_baseline(2,2:100),'b','LineWidth',3);
hold on
plot(Xn_extended(2,2:100),'--r','LineWidth',3);
title('Susceptible','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Fraction of the population','Fontsize',18)

figure(3);
plot((Xn_baseline(12,2:100)-1)*100,'b','LineWidth',3);
hold on
plot((Xn_extended(12,2:100)-1)*100,'--r','LineWidth',2);
title('Output','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Percentage deviation','Fontsize',18)

figure(4);
plot((Xn_baseline(9,2:100)-1)*100,'b','LineWidth',3);
hold on
plot((Xn_extended(9,2:100)-1)*100,'--r','LineWidth',2);
title('Inflation','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Percentage points (weekly)','Fontsize',18)

figure(5);
plot(Xn_baseline(10,2:100)*100,'b','LineWidth',3);
hold on
plot(Xn_extended(10,2:100)*100,'--r','LineWidth',2);
title('Policy rate','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Percentage points (weekly)','Fontsize',18)