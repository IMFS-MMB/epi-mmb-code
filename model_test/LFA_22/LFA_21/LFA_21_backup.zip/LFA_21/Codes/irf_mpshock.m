% This code generates the necessary inputs to produce Figures 3 to 5 in "The Limited Power of Monetary Policy in a Pandemic",
% Antoine Lepetit and Cristina Fuentes-Albero, November 2021.

%% Preparation

clear all
clc

mp_pandemic;

global M_ options_ oo_;
Tsim = 150;
options_.periods = Tsim;
options_.simul.maxit = 200; 
options_.dynatol.f = 1e-10;
options_.dynatol.x = 1e-10;

maxlag=1;
maxlead=1;
endo_simul = repmat(oo_.endo_simul(:,1),[1,Tsim+maxlag+maxlead]);
endo_simul(:,end) = oo_.endo_simul(:,end);
oo_.endo_simul = endo_simul;

% Calibrate shocks
mu = [zeros(Tsim+1,1)];
mp_shock = [zeros(Tsim+1,1)];
pi_s1_shock = [zeros(Tsim+1,1)];
pi_s2_shock = [0;0;0;0;-0.02;-0.04;-0.06;-0.08*ones(Tsim+1-7,1)];
pi_s3_shock = [-0.19;-0.19;-0.195;-0.195;-0.2025*ones(5,1);-0.205*ones(5,1);-0.2075*ones(10,1);-0.21*ones(Tsim+1-24,1)];

shocks = [mu,mp_shock,pi_s1_shock,pi_s2_shock,pi_s3_shock];

eps_t = shocks(1:2,:);
Tshock = size(eps_t,1);
nshock = size(eps_t,2);

%% Simulate baseline

Xn_baseline = endo_simul;

for h=1:Tshock
    
    display(sprintf('Now on time %d', h));
    
    options_.periods = Tsim-h+1;
    
    oo_.exo_simul = [zeros(1,nshock);eps_t(h,:);[zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),pi_s2_shock(h+1:end),pi_s3_shock(h+1:end)]];
    perfect_foresight_solver;
    
    Xn_baseline(:,h+1:end) = real(oo_.endo_simul(:,2:end));
    oo_.endo_simul = real(oo_.endo_simul(:,2:end));
    
end

save Xn_baseline

clear oo_.endo_simul oo_.exo_simul mp_shock shocks eps_t Tshock nshock;

%% Simulate alt-sims with unanticipated monetary policy shocks happening in different periods

Xn = zeros(26,152,100);

for j=1:100
    
  mp_shock = [zeros(j,1);-0.0001;zeros(Tsim+1-(j+1),1)];

  shocks = [mu,mp_shock,pi_s1_shock,pi_s2_shock,pi_s3_shock]; 

  eps_t = shocks(1:j+1,:);
  Tshock = size(eps_t,1);
  nshock = size(eps_t,2);

  oo_.endo_simul = endo_simul;
  Xn(:,:,j) = endo_simul;

  for h=1:Tshock
    
      display(sprintf('Now on time %d', h));
    
      options_.periods = Tsim-h+1;
    
      oo_.exo_simul = [zeros(1,nshock);eps_t(h,:);[zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),pi_s2_shock(h+1:end),pi_s3_shock(h+1:end)]];
      perfect_foresight_solver;
    
      Xn(:,h+1:end,j) = real(oo_.endo_simul(:,2:end));
      oo_.endo_simul = real(oo_.endo_simul(:,2:end));
    
  end
  
  clear oo_.endo_simul oo_.exo_simul mp_shock shocks eps_t Tshock nshock;

end

save Xn

%% Simulate alt-sims with anticipated monetary policy shocks happening in different periods

Xn_2 = zeros(26,152,100);

for j=1:100
    
  mp_shock = [zeros(j,1);-0.0001;zeros(Tsim+1-(j+1),1)];

  shocks = [mu,mp_shock,pi_s1_shock,pi_s2_shock,pi_s3_shock]; 

  eps_t = shocks(1:2,:);
  Tshock = size(eps_t,1);
  nshock = size(eps_t,2);

  oo_.endo_simul = endo_simul;
  Xn_2(:,:,j) = endo_simul;

  for h=1:Tshock
    
      display(sprintf('Now on time %d', h));
    
      options_.periods = Tsim-h+1;
    
      oo_.exo_simul = [zeros(1,nshock);eps_t(h,:);[zeros(Tsim-h+1,1),mp_shock(h+1:end),zeros(Tsim-h+1,1),pi_s2_shock(h+1:end),pi_s3_shock(h+1:end)]];
      perfect_foresight_solver;
    
      Xn_2(:,h+1:end,j) = real(oo_.endo_simul(:,2:end));
      oo_.endo_simul = real(oo_.endo_simul(:,2:end));
    
  end
  
  clear oo_.endo_simul oo_.exo_simul mp_shock shocks eps_t Tshock nshock;

end
 
save Xn_2

%% Simulate alt-sims with anticipated monetary policy shocks always at the same horizon but happening in different periods
% The horizon of the shock is 50 weeks, but we look at what happens when
% the shock is revealed to the public in periods 1,2,...,80.

Xn_3 = zeros(26,152,80);

for j=1:80
    
  mp_shock = [zeros(50+j,1);-0.0001;zeros(Tsim+1-(50+j+1),1)];

  shocks = [mu,mp_shock,pi_s1_shock,pi_s2_shock,pi_s3_shock]; 

  eps_t = shocks(1:j+1,:);
  Tshock = size(eps_t,1);
  nshock = size(eps_t,2);

  oo_.endo_simul = endo_simul;
  Xn_3(:,:,j) = endo_simul;

  for h=1:j
     
      display(sprintf('Now on time %d', h));
    
      options_.periods = Tsim-h+1;
    
      oo_.exo_simul = [zeros(1,nshock);eps_t(h,:);[zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),zeros(Tsim-h+1,1),pi_s2_shock(h+1:end),pi_s3_shock(h+1:end)]];
      perfect_foresight_solver;
    
      Xn_3(:,h+1:end,j) = real(oo_.endo_simul(:,2:end));
      oo_.endo_simul = real(oo_.endo_simul(:,2:end));
    
  end
  
  for h=j+1:Tshock
    
      display(sprintf('Now on time %d', h));
    
      options_.periods = Tsim-h+1;
    
      oo_.exo_simul = [zeros(1,nshock);eps_t(h,:);[zeros(Tsim-h+1,1),mp_shock(h+1:end),zeros(Tsim-h+1,1),pi_s2_shock(h+1:end),pi_s3_shock(h+1:end)]];
      perfect_foresight_solver;
    
      Xn_3(:,h+1:end,j) = real(oo_.endo_simul(:,2:end));
      oo_.endo_simul = real(oo_.endo_simul(:,2:end));
    
  end
  

end

save Xn_3