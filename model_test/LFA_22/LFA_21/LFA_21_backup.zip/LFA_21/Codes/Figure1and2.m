% Figures 1 and 2 in "The Limited Power of Monetary Policy in a Pandemic", Antoine
% Lepetit and Cristina Fuentes-Albero, November 2021.

dynare mp_pandemic_zlb

y_baseline = y;
infl_baseline = infl;
ffr_baseline = ffr;
i_baseline = i;
s_baseline = s;

figure(1);
plot(i_baseline(2:100),'b','LineWidth',3);
title('Infected Households','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Fraction of the population','Fontsize',18)

figure(2);
plot(s_baseline(2:100),'b','LineWidth',3);
title('Susceptible Households','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Fraction of the population','Fontsize',18)

figure(3);
plot((y_baseline(2:100)-1)*100,'b','LineWidth',3);
title('Output','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Percentage deviation','Fontsize',18)

figure(4);
plot((infl_baseline(2:100)-1)*100,'b','LineWidth',3);
title('Inflation','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Percentage points (weekly)','Fontsize',18)

figure(5);
plot(ffr_baseline(2:100)*100,'b','LineWidth',3);
title('Policy rate','Fontsize',20)
xlabel('Weeks','Fontsize',18)
ylabel('Percentage points (weekly)','Fontsize',18)