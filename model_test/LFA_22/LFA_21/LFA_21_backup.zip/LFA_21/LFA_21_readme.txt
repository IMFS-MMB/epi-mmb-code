How to replicate the results in "The Limited Power of Monetary Policy in a Pandemic", Antoine Lepetit and Cristina Fuentes-Albero, November 2021.
- SOFTWARE, OPERATING SYSTEM
Matlab 2020a
Dynare 4.5.6
Windows 10

Link to paper:
https://sites.google.com/site/cristinafuentesalbero/research


- FIGURE 1 and 2
Run Figure1and2.m. This programs calls the Dynare mod file mp_pandemic_zlb.mod, which contains the baseline version of the model under a Taylor rule and subject to the effective lower bound (ELB).
Expected computation time: a few minutes.
- FIGURE 3 to 5
Execute "dynare mp_pandemic.mod". This file contains a version of the model where, except for shocks, the real interest rate is kept fixed. Other than that, the program is the same as mp_pandemic_zlb.mod. 
After this is done, run irf_mpshock.m. This program calls the file mp_pandemic.m that is generated when executing the mod file and stores three matrices Xn, Xn_2, and Xn_3 which contain the impulse response functions to the monetary policy experiments shown in section 4.2 of the paper. 
To generate figures 3 to 5, run Figures3to5.m. This program reads from Xn, Xn_2, and Xn_3.
Expected computation time: about 3 hours.
- FIGURE 6 and 7
Execute "dynare mp_pandemic_zlb.mod" and "dynare mp_pandemic_extended.mod" one after the other:
- mp_pandemic_zlb.mod contains the baseline version of the model under a Taylor rule and subject to the effective lower bound.
- mp_pandemic_extended.mod contains a version of the model where the path of the federal funds rate can be exogenously set for a given number of periods. Other than that, the program is the same as mp_pandemic_zlb.mod. 
After this is done, run Figure6and7.m. This program calls the files mp_pandemic_zlb.m and mp_pandemic_extended.m that are generated when executing the mod files. It generates two simulations:
- The baseline simulation with monetary policy conducted according to a Taylor rule and subject to the ELB.
- An alternative simulation where the path of the federal funds rate is imposed to be the same as in the baseline simulation from periods 1 to 34 included (date of lift-off in the baseline simulation), kept at the ELB from periods 35 to 58 included, and governed by the model Taylor's rule from period 59 onwards.
Expected computation time: a few minutes.
- FIGURE 8
Execute "dynare mp_pandemic_nozlb". This code contains a version of the model where monetary policy is not subject to the ELB. Other than that, the program is the same as mp_pandemic_zlb.mod.
Run Figure8.m. This program calls the file mp_pandemic_nozlb.m that is generated when executing the mod file. 
Expected computation time: 5/10 minutes.